export function niceToMeetYou(name) { 
console.log(name);
}
