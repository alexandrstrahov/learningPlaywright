import {niceToMeetYou} from './modules.mjs';
console.log(niceToMeetYou('Pisos'));