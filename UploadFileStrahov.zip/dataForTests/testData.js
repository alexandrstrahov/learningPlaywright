const { expect } = require('@playwright/test');

module.exports = {
   image: image = ('./dataForTests/19.png')
   
  
}